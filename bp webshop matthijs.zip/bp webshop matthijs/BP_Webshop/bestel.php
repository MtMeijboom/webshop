<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="view/css/style.css">
    <link rel="stylesheet" href="view/css/bestelling.css">
    <script type="module" src="script.js"></script>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

</head>

<body>

<header>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="producten.php">Producten</a></li>
            <li><a href="admin.php">Admin</a></li>
            <li><a href="register.php">login</a></li>
            <li><a href="bestel.php"> <i class="fas fa-shopping-cart"></i> </a></li>
        </ul>
</header>

<main>

    <section>
        <div class="wrapper2">
    
            <div class="bestelTop">
                <div class="a1">Bestelling</div>
                <div class="a2">Totaal</div>
            </div>
            
            <div class="bestelContent">
                <div class="bestelling">

                    <img class="bestellingImg" src="view/images/hallo.png" alt="#">

                    <p>Naam: helemaal mooi</p>

                    <div class="aantal">
                        <p>Aantal: </p> 
                        <input type='tekst' name='aantaal' value='2' />
                    </div>
                    
                    <div class="totaal">
                        <p class="a">50 keer</p>
                        <p class="b">€420.69</p> 
                        <p class="c">totaal: €420,69</p>
                    </div>

                </div>
                <div class="bestelling">

                    <img class="bestellingImg" src="view/images/hallo.png" alt="#">

                    <p>Naam: helemaal mooi</p>

                    <div class="aantal">
                        <p>Aantal: </p> 
                        <input type='tekst' name='aantaal' value='2' />
                    </div>
                    
                    <div class="totaal">
                        <p class="a">50 keer</p>
                        <p class="b">€420.69</p> 
                        <p class="c">totaal: €420,69</p>
                    </div>

                </div>
                <div class="bestelling">

                    <img class="bestellingImg" src="view/images/hallo.png" alt="#">

                    <p>Naam: helemaal mooi</p>

                    <div class="aantal">
                        <p>Aantal: </p> 
                        <input type='tekst' name='aantaal' value='2' />
                    </div>
                    
                    <div class="totaal">
                        <p class="a">50 keer</p>
                        <p class="b">€420.69</p> 
                        <p class="c">totaal: €420,69</p>
                    </div>

                </div>
                <div class="bestelling">

                    <img class="bestellingImg" src="view/images/hallo.png" alt="#">

                    <p>Naam: helemaal mooi</p>

                    <div class="aantal">
                        <p>Aantal: </p> 
                        <input type='tekst' name='aantaal' value='2' />
                    </div>
                    
                    <div class="totaal">
                        <p class="a">50 keer</p>
                        <p class="b">€420.69</p> 
                        <p class="c">totaal: €420,69</p>
                    </div>

                </div>
                <div class="bestelling">

                    <img class="bestellingImg" src="view/images/hallo.png" alt="#">

                    <p>Naam: helemaal mooi</p>

                    <div class="aantal">
                        <p>Aantal: </p> 
                        <input type='tekst' name='aantaal' value='2' />
                    </div>
                    
                    <div class="totaal">
                        <p class="a">50 keer</p>
                        <p class="b">€420.69</p> 
                        <p class="c">totaal: €420,69</p>
                    </div>

                </div>


</div>

</div>
            </div>
            
            <div class="bestelTotaal">
                <div class="a1">Totaal</div>
                <div class="a2">€420,69</div>
            </div>
            
        </div>
   
    </section>

</main>

<footer>


    <div class="footerClaim">
        <div class="flex-center">
            <a href="https://www.instagram.com/radio.gaga/" target="_blank"><i class="fab fa-twitter fa-4x icon-3d"></i></a>
            <a href="https://twitter.com/radiogaganl" target="_blank"><i class="fab fa-instagram fa-4x icon-3d"></i></a>
            <a href="https://www.facebook.com/radiogaga.tv/" target="_blank"><i class="fab fa-facebook fa-4x icon-3d"></i></a>
            <a href="https://www.youtube.com/watch?v=azdwsXLmrHE&ab_channel=QueenOfficial" target="_blank"><i class="fab fa-youtube fa-4x icon-3d"></i></a>
        </div>
        
        <div style="display: grid;">
            <i class="claim">© matthijs website - 2021</i>
        </div>
        
    </div>

    <div class="footerLinks">
        <a href="index.php">Home</a>
        <a href="producten.php">Producten</a>
        <a href="contact.php">Contact</a>
        <a href="login.php">login</a>    
    </div>

</footer>


</body>


</html>