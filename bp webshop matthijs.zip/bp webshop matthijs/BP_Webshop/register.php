<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="view/css/style.css">
    <link rel="stylesheet" href="view/css/login.css">
    <script type="module" src="script.js"></script>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

</head>

<body>

<header>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="producten.php">Producten</a></li>
            <li><a href="admin.php">Admin</a></li>
            <li><a href="register.php">login</a></li>
            <li><a href="bestel.php"> <i class="fas fa-shopping-cart"></i> </a></li>
        </ul>
</header>

<main class="mainHome">

    <div class="loginContainer log">

        <h1>Login</h1>

        <form method="POST" class="loginForm">

            <b>Gebruiker: </b><input placeholder="Gebruiker" type="text" name="txtGebruiker">
            <b>Wachtwoord: </b><input placeholder="Wachtwoord" type="password" name="txtWachtwoord">

            <b></b>
            <input type="submit" name="btnlogin" value="Inloggen" />
        </form>
        
    </div>

    <div class="loginContainer">

        <h1>Registreren</h1>

        <form method="POST" class="loginForm">

            <b>Gebruiker: </b><input placeholder="Gebruiker" type="text" name="txtGebruiker">
            <b>Wachtwoord: </b><input placeholder="Wachtwoord" type="password" name="txtWachtwoord">

            <b>Voornaam: </b><input placeholder="Voornaam" type="text" name="txtVoornaam" />
            <b>Achternaam: </b><input placeholder="Achternaam" type="text" name="txtAchternaam" />
            <b>Email: </b><input placeholder="Email" type="email" name="txtMail" />
            <b>Telefoon: </b><input placeholder="Telefoon" type="text" name="txtTelefoon" />
            <b>Gebortedatum: </b><input type="date" name="gebDatum" />
            <b></b>
            <input type="submit" name="btnRegister" value="Register" />

            <?php
            require 'php/UserClass.php';
            
            $US = new users();

            $Add = $US->AddUser();
            $login = $US->LoginUser();
           
        ?>
        </form>
        
    </div>

    

</main>

<footer>

    

    <div class="footerClaim">
        <div class="flex-center">
            <a href="https://www.instagram.com/radio.gaga/" target="_blank"><i class="fab fa-twitter fa-4x icon-3d"></i></a>
            <a href="https://twitter.com/radiogaganl" target="_blank"><i class="fab fa-instagram fa-4x icon-3d"></i></a>
            <a href="https://www.facebook.com/radiogaga.tv/" target="_blank"><i class="fab fa-facebook fa-4x icon-3d"></i></a>
            <a href="https://www.youtube.com/watch?v=azdwsXLmrHE&ab_channel=QueenOfficial" target="_blank"><i class="fab fa-youtube fa-4x icon-3d"></i></a>
        </div>
        
        <div style="display: grid;">
            <i class="claim">© Matthijs - 2021</i>
        </div>
        
    </div>

    <div class="footerLinks">
        <a href="index.php">Home</a>
        <a href="producten.php">Producten</a>
        <a href="contact.php">Contact</a>
        <a href="login.php">login</a>    
    </div>

</footer>


</body>


</html>