<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="view/css/style.css">
    <link rel="stylesheet" href="view/css/products.css">
    <script type="module" src="script.js"></script>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

</head>

<body>

<header>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="producten.php">Producten</a></li>
            <li><a href="admin.php">Admin</a></li>
            <li><a href="register.php">login</a></li>
            <li><a href="bestel.php"> <i class="fas fa-shopping-cart"></i> </a></li>
        </ul>
</header>

<main>

    <section class="productSection">

   
        <form method="POST" class="searchBox">

            <div>
                <input class="searchInput"type="text" name="ItemSearch" placeholder="Search">


                <input type="submit" class="searchButton" name="BtnSearch" value="Zoek">
                    
                </input>
            </div>
           

        </form>

        <form method="POST" class="containerProducts">
        <?php
            require 'php/ProductClass.php';
            
            $PC = new product();
    
            $search = $PC->SearchProduct();
        ?>

        </form>

       

    </section>

</main>

<footer>



    <div class="footerClaim">
        <div class="flex-center">
            <a href="https://www.instagram.com/radio.gaga/" target="_blank"><i class="fab fa-twitter fa-4x icon-3d"></i></a>
            <a href="https://twitter.com/radiogaganl" target="_blank"><i class="fab fa-instagram fa-4x icon-3d"></i></a>
            <a href="https://www.facebook.com/radiogaga.tv/" target="_blank"><i class="fab fa-facebook fa-4x icon-3d"></i></a>
            <a href="https://www.youtube.com/watch?v=azdwsXLmrHE&ab_channel=QueenOfficial" target="_blank"><i class="fab fa-youtube fa-4x icon-3d"></i></a>
        </div>
        
        <div style="display: grid;">
            <i class="claim">© Matthijs website - 2021</i>
        </div>
        
    </div>

    <div class="footerLinks">
        <a href="index.php">Home</a>
        <a href="producten.php">Producten</a>
        <a href="contact.php">Contact</a>
        <a href="login.php">login</a>    
    </div>

</footer>


</body>


</html>