<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="view/css/style.css">
    <link rel="stylesheet" href="view/css/products.css">
    <script type="module" src="script.js"></script>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

</head>

<body>

<header>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="producten.php">Producten</a></li>
            <li><a href="admin.php">Admin</a></li>
            <li><a href="register.php">login</a></li>
            <li><a href="bestel.php"> <i class="fas fa-shopping-cart"></i> </a></li>
        </ul>
</header>

<main>

<section class="productSection">

   
<div class="searchBox">
  
        
       

        <form method="POST" class="containerInput">

                <div class="a">
                    <b>Naam: </b><input type='tekst' name='productnaam' placeholder='productNaam' />
                </div>

                <div class="b">
                    <b>Soort: </b> <input type='tekst' name='soort' placeholder='soort' />
                </div>
                
                <div class="c">
                    <b>Prijs €: </b> <input type='tekst' name='prijs' placeholder='prijs' />
                </div>
                
                <div class="d">
                    <b>voorraad: </b> <input type='tekst' name='voorraad' placeholder='voorraad' />
                </div>
                
                <div class="e">
                    <b>Foto: </b> <input type='tekst' name='img' placeholder='link' />
                </div>
                
                <input class="f" type='submit' name='btnToevoegen' value='Toevoegen' />
               
        </form>
</div>

<form method="POST" class="containerProductsAdmin">

        <?php
            require 'php/ProductClass.php';
            
            $PC = new product();
            $showProduct = $PC->ShowProductAdmin();
            $delete = $PC->DeleteProduct();
            $add = $PC->AddProduct();
            $edit = $PC->EditProduct();

            require 'php/UserClass.php';

            $US = new users();
            $showUser = $US->ShowUser();
        ?>

   
</form>
    


</section>


</main>

<footer>


    <div class="footerClaim">
        <div class="flex-center">
            <a href="https://www.instagram.com/radio.gaga/" target="_blank"><i class="fab fa-twitter fa-4x icon-3d"></i></a>
            <a href="https://twitter.com/radiogaganl" target="_blank"><i class="fab fa-instagram fa-4x icon-3d"></i></a>
            <a href="https://www.facebook.com/radiogaga.tv/" target="_blank"><i class="fab fa-facebook fa-4x icon-3d"></i></a>
            <a href="https://www.youtube.com/watch?v=azdwsXLmrHE&ab_channel=QueenOfficial" target="_blank"><i class="fab fa-youtube fa-4x icon-3d"></i></a>
        </div>
        
        <div style="display: grid;">
            <i class="claim">© Matthijs website - 2021</i>
        </div>
        
    </div>

    <div class="footerLinks">
        <a href="index.php">Home</a>
        <a href="producten.php">Producten</a>
        <a href="contact.php">Contact</a>
        <a href="login.php">login</a>    
    </div>

</footer>


</body>


</html>