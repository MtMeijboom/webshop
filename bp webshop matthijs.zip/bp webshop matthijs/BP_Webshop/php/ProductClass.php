<?php
    class product{
        

        public function ShowProductAdmin(){  
            include_once 'config.php';
            $db = new Database();
            $conn = $db->connect();

             #code...
             $query = "SELECT * FROM producten"; //Query om producten op te halen
             $stm = $conn->prepare($query);
             if($stm->execute()){
                   foreach($stm->fetchAll(PDO::FETCH_OBJ) as $product){ 
                echo "
                    <div class='mainContainer admin'>
                    <div class='".$product->productNaam."'>
                        <b>Product</b>
                    </div>
            
                    <div class='product content'>
                    <input name='PID' hidden readonly value='$product->PID'/>
                        <img class='productImg' src='".$product->foto."'  alt='#'>               
                        <div class='productContent'>
                            <b>Naam: </b><input type='tekst' name='productnaam' value='".$product->productNaam."' />
                            <b>Soort: </b> <input type='tekst' name='soort' value='".$product->soort."' />
                            <b>Prijs €: </b> <input type='tekst' name='prijs' value='".$product->prijs."' />
                            <b>voorraad: </b> <input type='tekst' name='voorraad' value='".$product->voorraad."' />
                            <b>Foto: </b> <input type='tekst' name='img' value='".$product->foto."' />
                        </div>
                    </div>
            
                    <div class='product adminButtons'>
                        <a href='#'><input type='submit' name='btnBekijk' value='Bekijk' /></a>
                        <input type='submit' name='btnEdit' value='Wijzig' />
                        <input type='submit' name='btnDelete' value='Delete' />
                    </div>
                </div>
                    ";
                    }
            }
        }

        public function SearchProduct(){
            include_once 'config.php';
            $db = new Database();
            $conn = $db->connect();

            if (isset($_POST['BtnSearch'])) 
                {
            
                    $zoek = "%".$_POST['ItemSearch']."%";
                    //query schrijven
                    $query = "SELECT * FROM producten WHERE productNaam like :waarde OR soort like :waarde";
                    //inlezen van query
                    $stm = $conn->prepare($query);
                    // aliassen koppeen aan waarden
                    $stm->bindParam(":waarde", $zoek);
                    // uitvoeren van de query
                    if($stm->execute() == true){
                    //resultaten ophalen
                    $result = $stm->fetchAll(PDO::FETCH_OBJ);
                    //doorlopen van de resultaten
                    foreach($result as $event){
                        echo "
                        <div class='mainContainer user'>
                            <div class='product titel'>
                                <b>Product</b>
                            </div>
            
                            <div class='product content'>
                                <img class='productImg' src='".$event->foto."'  alt='#'>               
                                <div class='productContent'>
                                <p>Naam: ".$event->productNaam."</p>
                                <p>Product: ".$event->soort."</p>
                                <p>Prijs: €".$event->prijs."</p>
                                <p>Aantal: ".$event->voorraad."</p>
                                </div>
                            </div>
            
                            <div class='product buttons'>
                                <a href=productDetail.php?id=$event->PID>Bekijk</a>
                                <input type='submit' name='btnBestel' value='Bestel' />
                            </div>
                        </div>
                    ";
                    }
                }else echo "Geen gegevens opgehaald!";
                }
        }


        public function ProductDetail(){
            include_once 'config.php';
            $db = new Database();
            $conn = $db->connect();

            if(isset($_GET['id'])){
        
                $id = $_GET['id']; 
                //query schrijven
                $query = "SELECT * FROM producten WHERE PID = :id";
                //query inlezen
                $stm = $conn->prepare($query);
                //aliassen koppelen aan de waarden
                $stm->bindParam(":id", $id);
                //query uitvoeren
                if($stm->execute() == true){
                  $product = $stm->fetch(PDO::FETCH_OBJ);
                  echo "  <img class='imgHome' src='$product->foto' alt='#'>

                  <div class='sectionContainer2'>
          
                      <H1>".$product->productNaam."</H1>
          
                      <p>Type: ".$product->soort."</p>
                      <p>Vooraad: ".$product->voorraad."</p>
                      <p>Prijs: €".$product->prijs."</p>
          
                      <div>
                          <a href='producten.php'><input type='submit' value='Producten' /></a>
                          <input type='submit' name='btnBestel' value='Bestel' />
                       </div>
                     
                  </div>";
                }else{echo "query kan niet worden uitgevoerd";}
        
            }
        }

        public function EditProduct(){
            include_once 'config.php';
            $db = new Database();
            $conn = $db->connect();
            #code...
            if(isset($_POST['btnEdit'])){
      
                //Variabelen ophalen
                $pid = 0;
                $productNaam = $_POST['productnaam'];
                $productSoort = $_POST['soort'];
                $productPrijs = $_POST['prijs'];
                $voorraad = $_POST['voorraad'];
                $productImg = $_POST['img'];
                
                //STAP 1 - Query schrijven
                $query = "UPDATE producten SET productNaam = :productnaam,
                     soort = :soort, prijs = :prijs,
                     voorraad = :voorraad, foto = :foto WHERE PID = :id";
                //STAP 2 - query inlezen
                $stm = $conn->prepare($query);
                //STAP 3 - Aliassen koppelen aan waarden
                $stm->bindparam(":id", $pid);
                $stm->bindParam(":productNaam", $productNaam);
                $stm->bindParam(":soort", $productSoort);
                $stm->bindParam(":prijs", $productPrijs);
                $stm->bindParam(":voorraad", $voorraad);
                $stm->bindParam(":foto", $productImg);
                
                //STAP 4 - Query uitvoeren naar de database
                if($stm->execute() == true){
                    echo "het werkt!";
                }else echo "Geen gegevens verstuurd!";
              } 
                
        }

        public function DeleteProduct(){
            include_once 'config.php';
            $db = new Database();
            $conn = $db->connect();
            #code...
            if(isset($_POST["btnDelete"])) {

                $productID = $_POST["PID"];
            
                $query = "DELETE FROM producten WHERE PID = :productId";
                $stm = $conn->prepare($query);
                $stm->bindparam(":productId", $productID);
                if ($stm->execute()) {
                    echo "Matthijs het werkt?";
            
                } else echo "ERROR!";
            }
        }

        public function AddProduct(){
            include_once 'config.php';
            $db = new Database();
            $conn = $db->connect();

            if (isset($_POST['btnToevoegen'])){ 
                $pid = 0;
                $productNaam = $_POST['productnaam'];
                $productSoort = $_POST['soort'];
                $productPrijs = $_POST['prijs'];
                $voorraad = $_POST['voorraad'];
                $productImg = $_POST['img'];
          
                $query = "INSERT into producten VALUES (:PID,
                                                        :productNaam,
                                                        :soort,
                                                        :prijs,
                                                        :voorraad,
                                                        :foto)";

                $stm = $conn->prepare($query);
                $stm->bindParam(":PID", $pid);
                $stm->bindParam(":productNaam", $productNaam);
                $stm->bindParam(":soort", $productSoort);
                $stm->bindParam(":prijs", $productPrijs);
                $stm->bindParam(":voorraad", $voorraad);
                $stm->bindParam(":foto", $productImg);
                
                if($stm->execute() == true){
                    echo "het werkt!";
                }else echo "Geen gegevens verstuurd!";
              } 
        }
    }

?>