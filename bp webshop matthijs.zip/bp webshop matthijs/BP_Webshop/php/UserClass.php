<?php

    class users{

        public function LoginUser(){
            include_once 'config.php';
            $db = new Database();
            $conn = $db->connect();
            #code...
            if(isset($_POST['btnlogin'])) {


                $gebruikersnaam = $_POST['txtGebruiker'];
                $wachtwoord = $_POST['txtWachtwoord'];
            
            
                $query = "SELECT * FROM account WHERE gebruiker = '$gebruikersnaam' AND wachtwoord = '$wachtwoord'";
                $stm = $conn->prepare($query);
                $stm->execute();
                $inlog = $stm->fetch(PDO::FETCH_OBJ);
            
                if($inlog != null) {
                    $_SESSION['btnLogin'] = $inlog;
                    Header("location: index.php");
                } else {
                    echo ("foute gebruikersnaam of wachtwoord ingevuld, probeer het opnieuw!");
                }
            
            }
        }

        public function AddUser(){
            include_once 'config.php';
            $db = new Database();
            $conn = $db->connect();
            #code...

            if (isset($_POST['btnRegister'])){ 
                $id = 0;
                $gebruiker = $_POST['txtGebruiker'];
                $wachtwoord = $_POST['txtWachtwoord'];
                $rechten = 0;
                $vnaam = $_POST['txtVoornaam'];
                $anaam = $_POST['txtAchternaam'];
                $email = $_POST['txtMail'];
                $tel = $_POST['txtTelefoon'];
                $gebdatum = $_POST['gebDatum'];
          
                $query = "INSERT into account VALUES (:AID,
                                                        :gebruiker,
                                                        :wachtwoord,
                                                        :rechten,
                                                        :voornaam,
                                                        :achternaam,
                                                        :email,
                                                        :telefoon,
                                                        :leeftijd)";
                $stm = $conn->prepare($query);
                $stm->bindParam(":AID", $id);
                $stm->bindParam(":gebruiker", $gebruiker);
                $stm->bindParam(":wachtwoord", $wachtwoord);
                $stm->bindParam(":rechten", $rechten);
                $stm->bindParam(":voornaam", $vnaam);
                $stm->bindParam(":achternaam", $anaam);
                $stm->bindParam(":email", $email);
                $stm->bindParam(":telefoon", $tel);
                $stm->bindParam(":leeftijd", $gebdatum);
                
                if ($stm->execute() == true) {
                    header("Refresh:0");
                }else echo "Geen gegevens verstuurd!";
              } 

        }

        public function ShowUser(){
            include_once 'config.php';
            $db = new Database();
            $conn = $db->connect();

             #code...
             $query = "SELECT * FROM account"; //Query om producten op te halen
             $stm = $conn->prepare($query);
             if($stm->execute()){
                   foreach($stm->fetchAll(PDO::FETCH_OBJ) as $user){ 
                echo "
                <div class='mainContainer admin'>
                <div class='product titel'>
                    <b>User</b>
                </div>
        
                <div class='product content'>
                    <div >
                        <b>Gebruiker: </b><input type='tekst' name='productnaam' value='".$user->gebruiker."' />
                        <b>Wachtwoord: </b><input type='tekst' name='productnaam' value='".$user->wachtwoord."' />
                        <b>Rechten: </b><input type='tekst' name='productnaam' value='".$user->rechten."' />
                    </div>   
        
                    <div class='productContent' >
                        <b>Naam: </b><input type='tekst' name='productnaam' value='".$user->voornaam."' />
                        <b>Achternaam: </b> <input type='tekst' name='soort' value='".$user->achternaam."' />
                        <b>Email: </b> <input type='tekst' name='prijs' value='".$user->email."' />
                        <b>Telefoon: </b> <input type='tekst' name='voorraad' value='".$user->telefoon."' />
                        <b>Gebortedatum: </b> <input type='tekst' name='img' value='".$user->leeftijd."' />
                    </div>
                </div>
        
                <div class='product adminButtons'>
                    <a href='#'><input type='submit' name='btnBekijk' value='Bekijk' /></a>
                    <input type='submit' name='btnEdit' value='Wijzig' />
                    <input type='submit' name='btnDelete' value='Delete' />
                </div>
            </div>
                    ";
                    }
            }
        }

        public function EditUser(){
            #code...
        }

        public function DeleteUser(){
            #code...
        }

    }

?>